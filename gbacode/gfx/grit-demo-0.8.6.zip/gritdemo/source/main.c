//
// An assortment of demonstrations of grit-conversions.
//
//! \file 
//! \author J Vijn
//! \date 20061128 - 20080404
//
/* === NOTES ===
	Yes, these test use a lot of magic numbers positioning, speeds 
	and tile indices. For a full game this is NOT advised, but in 
	these cases the exact positions aren't very important and 
	#defining all those constants would just cause extra clutter.
*/

#include <stdlib.h>
#include <string.h>
#include <tonc.h>

#include "menu.h"

// The headers have been included inside all_gfx.h automatically.
#include "all_gfx.h"

//! Set up a rectangle for text, with the non-text layers darkened for contrast. 
void win_textbox(int bgnr, int left, int top, int right, int bottom, int bldy)
{
	REG_WIN0H= left<<8 | right;
	REG_WIN0V=  top<<8 | bottom;
	REG_WIN0CNT= WIN_ALL | WIN_BLD;
	REG_WINOUTCNT= WIN_ALL;
	
	REG_BLDCNT= (BLD_ALL&~BIT(bgnr)) | BLD_BLACK;
	REG_BLDY= bldy;

	REG_DISPCNT |= DCNT_WIN0;

	tte_set_margins(left, top, right, bottom);
}


// Test a LZ77 compressed 16bpp bitmap.
void test_bmp16_lz77()
{
	irq_init(NULL);
	irq_add(II_VBLANK, NULL);

	LZ77UnCompVram(actiumBitmap, vid_mem);	// Uncomp bitmap

	// Init text
	tte_init_bmp_default(3);
	tte_init_con();

	REG_DISPCNT= DCNT_MODE3 | DCNT_BG2;

	tte_printf("#{m:4,4,236,32;P}LZ77 size: %d\nRaw size: %d", 
		actiumBitmapLen, M3_SIZE);		

	key_wait_till_hit(KEY_ANY);
}


// Test 8bpp bitmap.
void test_bmp8()
{
	irq_init(NULL);
	irq_add(II_VBLANK, NULL);

	GRIT_CPY(pal_bg_mem, gbapicPal);		// Copy palette
	RLUnCompVram(gbapicBitmap, vid_mem);	// Uncomp bitmap

	// Init text
	vid_page= vid_mem;
	tte_init_bmp_default(4);
	tte_init_con();

	REG_DISPCNT= DCNT_MODE4 | DCNT_BG2;

	tte_printf("#{m:4,4,236,32;P}RLE size: %d\nRaw size: %d", 
		gbapicBitmapLen, M4_SIZE);		

	key_wait_till_hit(KEY_ANY);
}


// Spritesheet(s) converted by a master grit file as well as separate
// grit files.
void test_smk_karts()
{
	irq_init(NULL);
	irq_add(II_VBLANK, NULL);

	oam_init(oam_mem, 128);

	GRIT_CPY(pal_obj_mem, smkPal);			// Copy palette
	pal_bg_mem[0]= CLR_DEAD;
	LZ77UnCompVram(boxTiles, tile_mem[4]);	// Init selection box

	// --- Kart LUTS ---

	const u16 kart_attr2[]= 
	{	0x1010, 0x3020, 0x0030, 0x2040, 0x2050, 0x0060, 0x3070, 0x1080	};

	const TILE * const kart_gfx[]= 
	{
		(TILE*)marioTiles, (TILE*)peachTiles, (TILE*)bowserTiles, (TILE*)koopaTiles,
		(TILE*)luigiTiles, (TILE*)yoshiTiles, (TILE*)donkeyTiles, (TILE*)toadTiles
	};

	// Animation frame lut for 32-> 22 frame mapping
	const u8 kart_frames[32]= 
	{
		  0,  1,  2,  3,  4,  5,  6,  7,
		  7,  8,  8,  9,  9, 10, 10, 11, 
		 11, 12, 12, 13, 13, 14, 14, 15, 
		 15, 16, 17, 18, 19, 20, 21,  0, 
	};

	// --- Demo ---
	int ii;
	int sel=0, frame=0, t= 0x800;

	OBJ_ATTR obj_buffer[9];
	obj_set_attr(&obj_buffer[0], ATTR0_SQUARE | 32, 
		ATTR1_SIZE_32x32 | 32, ATTR2_PALBANK(4) | 0);

	for(ii=0; ii<8; ii++)
	{
		obj_set_attr(&obj_buffer[ii+1], ATTR0_SQUARE | ATTR0_Y((ii/4)*48 + 32), 
			ATTR1_SIZE_32x32 | ATTR1_X(ii%4*48 + 32), kart_attr2[ii]);

		memcpy32(&tile_mem[4][(ii+1)*16], &kart_gfx[ii][7*16], 16*sizeof(TILE)/4);
	}

	REG_DISPCNT= DCNT_MODE0 | DCNT_OBJ | DCNT_OBJ_1D;

	while(1)
	{
		VBlankIntrWait();
		key_poll();
		oam_copy(oam_mem, obj_buffer, 9);

		// Change selected kart
		if(key_hit(KEY_DIR))
		{
			memcpy32(&tile_mem[4][(sel+1)*16], &kart_gfx[sel][7*16], 
				16*sizeof(TILE)/4);

			sel +=   key_tri_horz();
			sel += 4*key_tri_vert();
			sel &= 7;
			t= 0x800;
			obj_set_pos(&obj_buffer[0], sel%4*48 + 32, sel/4*48 + 32);
		}

		frame= kart_frames[(t>>8)&31];
		t += 100;

		memcpy32(&tile_mem[4][(sel+1)*16], &kart_gfx[sel][frame*16], 
			16*sizeof(TILE)/4);

		if(key_hit(KEY_START))
			break;
	}
}


// --------------------------------------------------------------------
// Brinstar variants
// --------------------------------------------------------------------

void brin_main()
{
	// Init for text.
	tte_init_chr4c_default(0, BG_CBB(0)|BG_SBB(31));
	tte_init_con();
	tte_set_drawg((fnDrawg)chr4c_drawg_b1cts_fast);

	win_textbox(0, 8, 8, 232, 22, 6);

	// -- Demo ---
	int x=128, y= 32;

	REG_BG2HOFS= x;
	REG_BG2VOFS= y;

	// Invisible map buildup!
	REG_BG2CNT= BG_CBB(2) | BG_SBB(28) | BG_REG_64x32;
	REG_DISPCNT= DCNT_MODE0 | DCNT_BG0 | DCNT_BG2 | DCNT_WIN0;

	while(1)
	{
		VBlankIntrWait();
		key_poll();

		x= clamp(x + key_tri_horz(), 0, 512+1-240);
		y= clamp(y + key_tri_vert(), 0, 256+1-160);

		REG_BG2HOFS= x;
		REG_BG2VOFS= y;

		tte_printf("#{es;P}%d, %d", x, y);
		
		if(key_hit(KEY_START))
			break;		
	}
}

// Test a regular SBB map
void test_regular_map()
{
	irq_init(NULL);
	irq_add(II_VBLANK, NULL);

	GRIT_CPY(pal_bg_mem, brinstar2mapPal);		// Load palette
	GRIT_CPY(&tile_mem[2], brinstar2mapTiles);	// Load tiles
	GRIT_CPY(&se_mem[28], brinstar2mapMap);		// Load map

	brin_main();
}


// Test metatiled SBB bitmap.
/*	How grit metatiling works.
	- The tiles are still in fooTiles, just like in non-metatiled maps
	- The metatiles are groups of screen-entries, indicating which 
	  gfx tiles are to be used. These are in fooMetaTiles.
	- The map description is in fooMetaMap.
*/
void test_meta_map()
{
	irq_init(NULL);
	irq_add(II_VBLANK, NULL);

	// Load palette, gfx and map
	GRIT_CPY(pal_bg_mem, brinstar2mmapPal);
	GRIT_CPY(&tile_mem[2], brinstar2mmapTiles);

	const u16 *mtiles= brinstar2mmapMetaTiles;
	const u16 *mmap= brinstar2mmapMetaMap;
	// Create the tilemap from the metamap
	int tx, ty, tofs, meta;
	u16 *pse= se_mem[28]; 

	for(ty=0; ty<32; ty++)
	{
		for(tx=0; tx<16; tx++)
		{
			meta= mmap[ty*16 + tx];		// metatile index
			tofs= ty*32*2+tx*2;			// screen-entry offset.

			pse[tofs+ 0]= mtiles[meta*4+0];
			pse[tofs+ 1]= mtiles[meta*4+1];
			pse[tofs+32]= mtiles[meta*4+2];
			pse[tofs+33]= mtiles[meta*4+3];
		}
	}
	
	brin_main();
}


// --------------------------------------------------------------------
// Brinstar vs GRF format
// --------------------------------------------------------------------

#define CHUNK_ID(a,b,c,d) ((u32)( (a) | (b)<<8 | (c)<<16 | (d)<<24 ))

#define ID_RIFF		CHUNK_ID('R','I','F','F')
#define ID_LIST		CHUNK_ID('L','I','S','T')
#define ID_GRF		CHUNK_ID('G','R','F',' ')

struct GrfHeader
{
	union {
		u8 attrs[4];
		struct {
			u8	gfxAttr, mapAttr, mmapAttr, palAttr;
		};
	};
	u8	tileWidth, tileHeight;
	u8	metaWidth, metaHeight;
	u32	gfxWidth, gfxHeight;
};

//! Decompress a GRF item.
bool grf_decomp(const void *src, void *dst)
{
	if(src==NULL || dst == NULL)
		return false;

	u32 header= *(u32*)src;
	uint size= header>>8;
	
	switch(header & 0xF0)
	{
	case 0x00:		// No compression
		tonccpy(dst, (u8*)src+4, size);	return true;		
	case 0x10:		// LZ77
		LZ77UnCompVram(src, dst);		return true;
	case 0x20:		// Huffman
		HuffUnComp(src, dst);			return true;
	case 0x30:		// RLE
		RLUnCompVram(src, dst);			return true;
	default:
		return false;		
	}
}

//! Load grf data
bool grf_load(const void *src, void *gfxDst, void *mapDst, void *palDst)
{
	u32 *src32= (u32*)src, id;
	
	// Must start with "RIFF" - "GRF "
	if(src == NULL || src32[0] != ID_RIFF || src32[2] != ID_GRF)
		return false;
	
	uint sizeMax= src32[1]-4;	// Size of GRF data
	src32 += 3;					// Skip RIFF ID and size
	
	//# For the moment, the header ("HDR ") and metatile ("MTIL","MMAP") 
	//# sections are ignored, as they are somewhat icky.
	
	uint ii, size;
	for(ii=0; ii<sizeMax; ii += size+8)
	{
		id= src32[0];
		size= src32[1];
		switch(id)
		{
		case CHUNK_ID('G','F','X',' '):
			grf_decomp(&src32[2], gfxDst);	break;

		case CHUNK_ID('M','A','P',' '):
			grf_decomp(&src32[2], mapDst);	break;
			
		case CHUNK_ID('P','A','L',' '):
			grf_decomp(&src32[2], palDst);	break;
		}
		src32 += (size+8)/4;
	}

	return true;
}

//! Test grf loader.
void test_grf()
{
	irq_init(NULL);
	irq_add(II_VBLANK, NULL);
	
	grf_load(brinstar2grfGrf, &tile_mem[2], &se_mem[28], pal_bg_mem);
	
	brin_main();
}

// --------------------------------------------------------------------
// 
// --------------------------------------------------------------------

//! Affine map test.
void test_affine_map()
{
	irq_init(NULL);
	irq_add(II_VBLANK, NULL);

	// Load palette, gfx and map
	GRIT_CPY(pal_bg_mem, bc1floorPal);
	GRIT_CPY(&tile_mem[2], bc1floorTiles);
	GRIT_CPY(&se_mem[24], bc1floorMap);
	pal_bg_mem[0]= CLR_BLACK;

	// Init for text.
	tte_init_chr4c_default(0, BG_CBB(0)|BG_SBB(23));
	tte_init_con();

	win_textbox(0, 8, 8, 232, 22, 6);

	// Screen/bg settings
	REG_BG2CNT= BG_CBB(2) | BG_SBB(24) | BG_AFF_128x128;
	REG_BG_AFFINE[2]= bg_aff_default;

	REG_DISPCNT= DCNT_MODE1 | DCNT_BG0 | DCNT_BG2 | DCNT_WIN0;

	// --- Demo ---
	int x=880<<8, y=632<<8, z= 256;
	BG_AFFINE *bga= &REG_BG_AFFINE[2];

	while(1)
	{
		VBlankIntrWait();
		key_poll();

		x= clamp(x + 2*z*key_tri_horz(), 0, (1024+1)<<8);
		y= clamp(y + 2*z*key_tri_vert(), 0, (1024+1)<<8);
		z= clamp(z + 32*key_tri_fire(), 128, 1024+1);
		
		bga->dx= x;
		bga->dy= y;
		bga->pa= z;
		bga->pd= z;

		tte_printf("#{es;P}(%d,%d,%d)", x>>8, y>>8, z);

		if(key_hit(KEY_START))
			break;
	}
}


// Using a shared tileset. Everything's LZ77 compressed.
void test_shared_tiles()
{
	irq_init(NULL);
	irq_add(II_VBLANK, NULL);

	LZ77UnCompVram(level1Pal, pal_bg_mem);
	LZ77UnCompVram(level1Tiles, tile_mem[2]);

	// Init for text.
	tte_init_chr4c_default(0, BG_CBB(0)|BG_SBB(31));
	tte_init_con();
	tte_set_drawg((fnDrawg)chr4c_drawg_b1cts_fast);

	win_textbox(0, 8, 8, 232, 22, 6);

	// Screen/bg settings
	REG_BG2HOFS= 8;
	REG_BG2VOFS= 8;

	REG_BG2CNT= BG_CBB(2) | BG_SBB(28) | BG_8BPP | BG_REG_32x32;
	REG_DISPCNT= DCNT_MODE0 | DCNT_BG0 | DCNT_BG2 | DCNT_WIN0;

	// --- Globals ---
	enum dirs { WEST=1, NORTH=2, EAST=4, SOUTH=8 };
	
#if 0
	Map connections:
		a	b	c	d	e	f
	1		# - #
				|
	2			#		# - #
				|		|
	3	# - # - # - # - #
			|
	4		# -	# -	#
				|
	5			#
				|
	6		# - # - #
#endif

	// Map look-ups.
	// NOTE: the map look-ups are done for ease of use, not space 
	// or maintainability. So yes, magic numbers and non-sparseness.
	const u8 map_conns[8][8]= 
	{
		{	0,  4,  9,  0,  0,  0,  0,  0	}, 
		{	0,  0, 10,  0, 12,  1,  0,  0	}, 
		{	4, 13,  7,  5,  3,  0,  0,  0	}, 
		{	0,  6, 13,  1,  0,  0,  0,  0	}, 
		{	0,  0, 10,  0,  0,  0,  0,  0	}, 
		{	0,  4,  7,  1,  0,  0,  0,  0	}, 
		{	0,  0,  0,  0,  0,  0,  0,  0	}, 
		{	0,  0,  0,  0,  0,  0,  0,  0	}, 
	};

	const u8 map_ids[8][8]= 
	{
		{	-1,  1,  5, -1, -1, -1, -1, -1	}, 
		{	-1, -1,  6, -1, 14, 16, -1, -1	}, 
		{	 0,  2,  7, 11, 15, -1, -1, -1	}, 
		{	-1,  3,  8, 12, -1, -1, -1, -1	}, 
		{	-1, -1,  9, -1, -1, -1, -1, -1	}, 
		{	-1,  4, 10, 13, -1, -1, -1, -1	}, 
		{	-1, -1, -1, -1, -1, -1, -1, -1	}, 
		{	-1, -1, -1, -1, -1, -1, -1, -1	}, 
	};

	const void *map_ptrs[]= 
	{
		level1_a3Map,
		level1_b1Map, level1_b3Map, level1_b4Map, level1_b6Map, 
		level1_c1Map, level1_c2Map, level1_c3Map, level1_c4Map, 
		level1_c5Map, level1_c6Map, 
		level1_d3Map, level1_d4Map,	level1_d6Map,  
		level1_e2Map, level1_e3Map, 
		level1_f2Map, 
	};

	// --- Demo ---
	int mx= 2, my= 5;	// Map position

	LZ77UnCompVram(map_ptrs[map_ids[my][mx]], se_mem[28]);
	tte_printf("#{es;P}%c%d", mx+'A', my+1);

	while(1)
	{
		VBlankIntrWait();
		key_poll();

		if(key_hit(KEY_DIR))
		{
			bool bMove= false;
			if(key_hit(KEY_LEFT ) && (map_conns[my][mx]& WEST) )
			{	mx--;	bMove= true;	}
			else if(key_hit(KEY_UP   ) && (map_conns[my][mx]&NORTH) )
			{	my--;	bMove= true;	}
			else if(key_hit(KEY_RIGHT) && (map_conns[my][mx]& EAST) )
			{	mx++;	bMove= true;	}
			else if(key_hit(KEY_DOWN ) && (map_conns[my][mx]&SOUTH) )
			{	my++;	bMove= true;	}
			
			if(bMove)
			{
				LZ77UnCompVram(map_ptrs[map_ids[my][mx]], se_mem[28]);
				tte_printf("#{es;P}%c%d", mx+'A', my+1);
			}
		}
		
		if(key_hit(KEY_START))
			break;					
	}
}

//! Show a palette merging example.
void test_palmerge()
{
	irq_init(NULL);
	irq_add(II_VBLANK, NULL);

	TSurface srf;
	srf_init(&srf, SRF_BMP8, NULL, 32, 32, 8, pal_bg_mem);

	// Init text
	tte_init_bmp_default(4);
	tte_init_con();
	
	// Copy the palette and blit the images
	GRIT_CPY(pal_bg_mem, palmergePal);

	srf_set_ptr(&srf, pmerge_aBitmap);
	sbmp8_blit(&m4_surface, 8,  8, 32, 32, &srf, 0, 0);
	
	srf_set_ptr(&srf, pmerge_bBitmap);
	sbmp8_blit(&m4_surface, 8, 48, 32, 32, &srf, 0, 0);
	
	srf_set_ptr(&srf, pmerge_cBitmap);
	sbmp8_blit(&m4_surface, 8, 88, 32, 32, &srf, 0, 0);

	// Create a palette bitmap
	int ix, iy;
	for(iy=0; iy<16; iy++)
		for(ix=0; ix<16; ix++)
			sbmp8_rect(&m4_surface, 101+ix*8, 9+iy*8, 107+ix*8, 15+iy*8, iy*16+ix);

	REG_DISPCNT= DCNT_MODE4 | DCNT_BG2;
	
	key_wait_till_hit(KEY_ANY);
}

const TMenuItem cUnits[]=
{
	{
		"LZ77 16bpp bitmap", 
		"Display a mode 3 bitmap, LZ77 compressed.\n"
		"Options: #{ci:22}-gb -gB16 -gzl",
		test_bmp16_lz77
	}, 
	{
		"RLE 8bpp bitmap", 
		"Display a mode 4 bitmap, RLE compressed.\n"
		"Options: #{ci:22}-gb -gB8 -gzr", 
		test_bmp8
	},
	{
		"Sprite sheet(s)", 
		"Karts from SMK. Multiple 32x32 sprite sheets via\n"
		"a master grit file. Palette converted separately.\n"
		"Arrows select and rotate the karts.\n"
		"Options: #{ci:22}-gB4 -Mw4 -Mh4 -p!",
		test_smk_karts
	}, 
	{
		"Regular map", 
		"A 512x256p tilemap, in SBB layout. Scroll with\narrows.\n"
		"Options: #{ci:22}-gB4 -mR4 -mLs", 
		test_regular_map
	},
	{
		"Meta map", 
		"A 512x256p tilemap with 2x2 metatiles. Scroll\nwith arrows.\n"
		"Options: #{ci:22}-gB4 -mR4 -mLs -Mw2 -Mh2", 
		test_meta_map
	},
	{
		"gfx, map & palette as GRF", 
		"GRF (Grit RIFF File) is a chunked binary format \n"
		"with some metadata, allowing for a single, simple\n"
		"file loader, regardless of conversion and \n"
		"compression specifics.\n"
		"Options: #{ci:22} -gB4 -mR4 -mLs -gzl -mzr -fr",
		test_grf
	},
	{
		"Affine map", 
		"A 1024x1024p affine map. Note that it's a \n"
		"byte-array instead of the default u16 array.\n"
		"Scroll with arrows, scale with A/B\n"
		"Options: #{ci:22}-mRa -mLa -mu8", 
		test_affine_map
	},
	{
		"Shared tileset", 
		"All files in the 'level1' directory are maps with a\n"
		"shared tileset. The data has been converted with\n"
		"a custom rule.\n"
		"Basic rule:\n"
		"#{ci:22}   grit $^ -o$@ -mR8 -Zl -fa -gS -S level1\n",
		test_shared_tiles
	},
	{
		"Palette merging", 
		"Reduce the numbers of palette-entries used and \n"
		"merge palettes from multiple files. The numbers \n"
		"indicate the original pal-indices.\n"
		"Options: #{ci:22}-gb -gB8 -pS -S pmerge", 
		test_palmerge
	}
};

int main()
{
	irq_init(NULL);
	irq_add(II_VBLANK, NULL);

	TMenu menu;
	menu_create(&menu, cUnits, countof(cUnits));
	
	while(1)
	{
		menu_init(&menu);
		menu_run(&menu);
		menu_act(&menu);
	}

	while(1)
	{
		VBlankIntrWait();
		key_poll();
	}
}

// EOF
