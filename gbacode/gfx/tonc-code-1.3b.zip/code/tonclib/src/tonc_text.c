//
//  Text system file
//
//! \file tonc_text.c
//! \author J Vijn
//! \date 20060605 - 20060605
//
// === NOTES ===
// * Since BitUnPack doesn't always work properly (VBA), I've put 
//   txt_bup_1toX in here to remedy that. Wish I didn't have to. 

#include "tonc_text.h"

// === GLOBALS ========================================================

u8 txt_lut[256];

TXT_BASE __txt_base;
TXT_BASE *gptxt= &__txt_base;

// === FUNCTIONS ======================================================

void txt_init_std()
{
	gptxt->dx= gptxt->dy= 8;

	gptxt->dst0= vid_mem;
	gptxt->font= (u32*)toncfontTiles;
	gptxt->chars= txt_lut;
	gptxt->cws= NULL;

	int ii;
	for(ii=0; ii<96; ii++)
		gptxt->chars[ii+32]= ii;
}

void txt_bup_1toX(void *dstv, const void *srcv, u32 len, int bpp, u32 base)
{
	u32 *src= (u32*)srcv;
	u32 *dst= (u32*)dstv;

	len= (len*bpp+3)>>2;		// # dst words
	u32 bBase0= base&(1<<31);	// add to 0 too?
	base &= ~(1<<31);


	u32 swd=0, ssh=32;	// src data and shift
	u32 dwd, dsh;		// dst data and shift
	while(len--)
	{
		if(ssh >= 32)
		{
			swd= *src++;
			ssh= 0;
		}
		dwd=0;
		for(dsh=0; dsh<32; dsh += bpp)
		{
			u32 wd= swd&1;
			if(wd || bBase0)
				wd += base;
			dwd |= wd<<dsh;
			swd >>= 1;
			ssh++;
		}

		*dst++= dwd;
	}
}

// EOF
