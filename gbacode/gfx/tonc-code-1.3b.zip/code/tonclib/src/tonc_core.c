//
//  Core stuff: keys, interrupts and misc
//
//! \file tonc_core.c
//! \author J Vijn
//! \date 20060508 - 20060508
//
// === NOTES ===

#include "tonc_memmap.h"

// === CONSTANTS ======================================================

const u8 oam_sizes[3][4][2]=
{
	{ { 8, 8}, {16,16}, {32,32}, {64,64} }, 
	{ {16, 8}, {32, 8}, {32,16}, {64,32} },
	{ { 8,16}, { 8,32}, {16,32}, {32,64} },
};

const BG_AFFINE bg_aff_dflt= { 256, 0, 0, 256, 0, 0 };

const u32 __snd_rates[12]=
{
	8013, 7566, 7144, 6742, // C , C#, D , D#
	6362, 6005, 5666, 5346, // E , F , F#, G
	5048, 4766, 4499, 4246  // G#, A , A#, B
};

// === MACROS =========================================================


// === CLASSES ========================================================
// === GLOBALS ========================================================

int __qran_seed= 42;

u16 __key_curr= 0, __key_prev= 0;
COLOR *vid_page= vid_mem_back;


// === FUNCTIONS ======================================================

// --- random numbers -------------------------------------------------

int sqran(int seed)
{	
	int old= __qran_seed;
	__qran_seed= seed; 
	return old;	
}

// --- misc -----------------------------------------------------------

//! Get the octant that (\a x, \a y) is in.
/*!	This function divides the circle in 8 parts. The angle 
*	starts at the \a y=0 line and then moves in the direction
*	of the \a x=0 line. On the screen, this would be like
*	starting at the 3 o'clock position and moving clockwise 
*/
u32 octant(int x, int y)
{
    u32 oct=0;
    if(y<0) { oct ^= 7; y=-y; }
    if(x<0) { oct ^= 3; x=-x; }
    if(x<y) { oct ^= 1; }
    return oct;
}

//! Get the rotated octant that (\a x, \a y) is in.
/*!	Like \c octant() but with a twist. The 0-octant starts 
*	22.5� earlier so that 3 o'clock falls in the middle of 
*	octant 0, instead of at its start. This can be useful for 
*	8 directional pointing.
*/
u32 octant_rot(int x0, int y0)
{
	//rotate by pi/8: (.9: sin: 195.9; cos 473.0)
	int x= 473*x0 - 196*y0;
	int y= 196*x0 + 473*y0;

    u32 oct=0;
    if(y<0) { oct ^= 7; y=-y; }
    if(x<0) { oct ^= 3; x=-x; }
    if(x<y) { oct ^= 1; }
    return oct;
}

