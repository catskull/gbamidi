//
//  Tiled background stuff
//
//! \file tonc_bg.c
//! \author J Vijn
//! \date 20061112 - 20061117
//
// === NOTES ===
// * Empty, isn't it :P


#include "tonc_memmap.h"
#include "tonc_video.h"

// === CONSTANTS ======================================================
// === CLASSES ========================================================
// === GLOBALS ========================================================

// === PROTOTYPES =====================================================

// === MACROS =========================================================
// === INLINES=========================================================
// === FUNCTIONS ======================================================

//! Create a framed rectangle.
/*! In contrast to se_frame(), se_frame_ex() uses nine tiles starting at 
*	\a se0 for the frame, which indicate the borders and center for the
*	window.
*	\note	Rectangle is nor normalized.
*/
void se_window(SCR_ENTRY *sbb, int ll, int tt, int rr, int bb, SCR_ENTRY se0)
{
	int ix, iy;
	rr -= (ll+1);
	bb -= (tt+1);

	sbb += tt*32+ll;

	sbb[       0]= se0;
	sbb[      rr]= se0+2;
	sbb[bb*32   ]= se0+6;
	sbb[bb*32+rr]= se0+8;

	// horizontal
	for(ix=1; ix<rr; ix++)
	{
		sbb[      ix]= se0+1;
		sbb[32*bb+ix]= se0+7;
	}

	// vertical + inside
	sbb += 32;
	for(iy=1; iy<bb; iy++)
	{
		sbb[ 0]= se0+3;
		for(ix=1; ix<rr; ix++)
			sbb[ix]= se0+4;
		sbb[rr]= se0+5;
		sbb += 32;
	}
}


// EOF
