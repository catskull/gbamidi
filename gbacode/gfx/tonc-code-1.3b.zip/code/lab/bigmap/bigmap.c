//
//  Big map scrolling and sprite animation
//
//! \file bigmap.c
//! \author J Vijn
//! \date 20060508 - 20070216
//
// === NOTES ===


#include <stdio.h>
#include <string.h>
#include <tonc.h>

#include "link.h"

#include "kakariko.h"
#include "link_gfx.h"


#define kakarikoMapPitch 128

// === CONSTANTS ======================================================
// === CLASSES ========================================================


typedef struct VIEWPORT
{
	int x, xmin, xmax, xpage;
	int y, ymin, ymax, ypage;
} VIEWPORT;


typedef struct BGTYPE
{
	union
	{
		u32 state;			//!< Background state
		struct
		{
			u16 flags;
			u16 cnt;
		};
	};
	// Destination data
	SCR_ENTRY *dst_map;		//!< Screenblock pointer	
	// Source data
	SCR_ENTRY *src_map;		//!< Source map address
	u32 src_map_width;		//!< Source map width
	u32 src_map_height;		//!< Source map height
	FIXED map_x;			//!< X-coord on map (.8f)
	FIXED map_y;			//!< Y-coord on map (.8f)
} BGTYPE;


// === GLOBALS ========================================================


VIEWPORT g_vp= 
{
	0, 0, 1024, 240, 
	0, 0, 1024, 160, 
};

BGTYPE g_bg;

OBJ_ATTR obj_buffer[128];

TSprite g_link;


// === PROTOTYPES =====================================================

INLINE void vp_center(VIEWPORT *vp, FIXED x, FIXED y);
void vp_set_pos(VIEWPORT *vp, FIXED x, FIXED y);

// === MACROS =========================================================
// === INLINES=========================================================
// === FUNCTIONS ======================================================


// --- VIEWPORT ---

INLINE void vp_center(VIEWPORT *vp, int x, int y)
{	vp_set_pos(vp, x - vp->xpage/2, y - vp->ypage/2);	}


void vp_set_pos(VIEWPORT *vp, int x, int y)
{
	vp->x= clamp(x, vp->xmin, vp->xmax - vp->xpage);
	vp->y= clamp(y, vp->ymin, vp->ymax - vp->ypage);
}


// --- BGTYPE ---

void bgt_init(BGTYPE *bgt, int bgnr, u32 ctrl, 
	const void *map, u32 map_width, u32 map_height)
{
	memset(bgt, 0, sizeof(BGTYPE));

	bgt->flags= bgnr;
	bgt->cnt= ctrl;
	bgt->dst_map= se_mem[BF_GET(ctrl, BG_SBB)];

	REG_BGCNT[bgnr]= ctrl;
	REG_BG_OFS[bgnr].x= 0;
	REG_BG_OFS[bgnr].y= 0;


	bgt->src_map= (SCR_ENTRY*)map;
	bgt->src_map_width= map_width;
	bgt->src_map_height= map_height;

	int ix, iy;
	SCR_ENTRY *dst= bgt->dst_map, *src= bgt->src_map;
	for(iy=0; iy<32; iy++)
		for(ix=0; ix<32; ix++)
			dst[iy*32+ix]= src[	iy*bgt->src_map_width+ix];
}

void bgt_colcpy(BGTYPE *bgt, int tx, int ty)
{
	int iy, y0= ty&31;

	int srcP= bgt->src_map_width;	
	SCR_ENTRY *srcL= &bgt->src_map[ty*srcP + tx];
	SCR_ENTRY *dstL= &bgt->dst_map[y0*32 + (tx&31)];

	for(iy=y0; iy<32; iy++)
	{	*dstL= *srcL;	dstL += 32;	srcL += srcP;	}

	dstL -= 1024;

	for(iy=0; iy<y0; iy++)
	{	*dstL= *srcL;	dstL += 32;	srcL += srcP;	}			
}

void bgt_rowcpy(BGTYPE *bgt, int tx, int ty)
{
	int ix, x0= tx&31;

	int srcP= bgt->src_map_width;	
	SCR_ENTRY *srcL= &bgt->src_map[ty*srcP + tx];
	SCR_ENTRY *dstL= &bgt->dst_map[(ty&31)*32 + x0];

	for(ix=x0; ix<32; ix++)
		*dstL++= *srcL++;

	dstL -= 32;

	for(ix=0; ix<x0; ix++)
		*dstL++= *srcL++;
}

void bgt_update(BGTYPE *bgt, VIEWPORT *vp)
{
	// Pixel coords
	int vx= vp->x, vy= vp->y;
	int bx= bgt->map_x, by= bgt->map_y;

	// Tile coords
	int tvx= vx>>3, tvy= vy>>3;
	int tbx= bx>>3, tby= by>>3;

	// Basically, we need another row/col when the viewport
	// exposes another row/col, i.e., if the tile coords
	// have changed

	if(tvx < tbx)		// add on left
		bgt_colcpy(bgt, tvx, tvy);
	else if(tvx > tbx)	// add on right
		bgt_colcpy(bgt, tvx+31, tvy);

	if(tvy < tby)		// add on top
		bgt_rowcpy(bgt, tvx, tvy);
	else if(tvy > tby)	// add on bottom
		bgt_rowcpy(bgt, tvx, tvy+31);

	// Update BGTYPE and reg-offsets
	int bgnr= bgt->flags;
	REG_BG_OFS[bgnr].x= bgt->map_x= vx;
	REG_BG_OFS[bgnr].y= bgt->map_y= vy;
}

void init_main()
{
	// Basic setups
	irq_init(NULL);
	IRQ_SET(VBLANK);
	oam_init(obj_buffer, 128);

	// Bigmap setup
	LZ77UnCompVram(kakarikoTiles, tile_mem[0]);
	GIT_CPY(pal_bg_mem, kakarikoPal);

	bgt_init(&g_bg, 1, BG_CBB(0)|BG_SBB(29), kakarikoMap, 
		128, 128);

	// Object setup
	GIT_CPY(pal_obj_mem, link_gfxPal);
	GIT_CPY(tile_mem[4], link_gfxTiles);

	link_init(&g_link, 120<<8, 80<<8, 0);

	txt_init_std();
	txt_init_se(0, BG_CBB(3)|BG_SBB(28), 0xF000, 0x0DEFC0DE, 0xEE);

	REG_DISPCNT= DCNT_MODE0 | DCNT_BG0 | DCNT_BG1 | DCNT_OBJ | DCNT_OBJ_1D;
}

int main()
{
	init_main();
	
	int x, y;
	char str[32];

	while(1)
	{
		VBlankIntrWait();

		key_poll();

		link_input(&g_link);
		link_animate(&g_link);
		link_move(&g_link);

		x= g_link.x>>8, y= g_link.y>>8;

		vp_center(&g_vp, x, y);
		oam_copy(oam_mem, obj_buffer, 128);

		SBB_CLEAR(28);
		siprintf(str, "(x,y) = (%d,%d)", x, y);
		se_puts(8, 8, str, 0xF000);
		siprintf(str, "(vx,vy) = (%d,%d)", g_vp.x, g_vp.y);
		se_puts(8, 16, str, 0xF000);

		bgt_update(&g_bg, &g_vp);
	}

	return 0;
}

// EOF
