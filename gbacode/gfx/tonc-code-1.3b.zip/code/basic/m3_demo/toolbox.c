//
// toolbox.c
// 
// Tools source for m3_dmeo
// 
// (20060922-20060922, cearn)
//
// === NOTES ===
// * This is a _small_ set of typedefs, #defines and inlines that can 
//   be found in tonclib, and might not represent the 
//   final forms.

#include "toolbox.h"


//! Fill the mode 3 background with color \a clr.
void m3_fill(COLOR clr)	
{	
	int ii;
	u32 *dst= (u32*)vid_mem;
	u32 wd= (clr<<16) | clr;

	for(ii=0; ii<M3_SIZE/4; ii++)
		*dst++= wd;
}

//! Draw a line in 16bit mode; internal routine
/*!	\param dst		Destination buffer.
*	\param dx		Horizontal line length.
*	\param dy		Vertical line length.
*	\param clr		Color to draw.
*	\param pitch	Pitch of buffer.
*/
void bm16_line(u16 *dst, int dx, int dy, COLOR clr, int pitch)
{
	int ii, xstep, ystep, dd;
	
	// --- Normalization ---

	if(dx<0)
	{	xstep= -1;	dx= -dx;	}
	else
		xstep= +1;

	if(dy<0)
	{	ystep= -pitch;	dy= -dy;	}
	else
		ystep= +pitch;

	// --- Drawing ---

	if(dy == 0)			// Horizontal
	{
		for(ii=0; ii<=dx; ii++)
			dst[ii*xstep]= clr;
	}
	else if(dx == 0)	// Vertical
	{
		for(ii=0; ii<=dy; ii++)
			dst[ii*ystep]= clr;
	}
	else if(dx>=dy)		// Diagonal, slope <= 1
	{
		dd= 2*dy - dx;

		for(ii=0; ii<=dx; ii++)
		{
			*dst= clr;
			if(dd >= 0)
			{	dd -= 2*dx;	dst += ystep;	}

			dd += 2*dy;
			dst += xstep;
		}				
	}
	else				// Diagonal, slope > 1
	{
		dd= 2*dx - dy;

		for(ii=0; ii<=dy; ii++)
		{
			*dst= clr;
			if(dd >= 0)
			{	dd -= 2*dy;	dst += xstep;	}

			dd += 2*dx;
			dst += ystep;
		}		
	}
}


//! Draw a rectangle in 16bit mode; internal routine.
/*!	\param dst		Destination buffer.
*	\param width	Rectangle width.
*	\paral height	Rectangle height. 
*	\param clrid	Color index to draw.
*	\param pitch	Pitch of buffer.
*/
void bm16_rect(u16 *dst, int width, int height, u16 clr, int pitch)
{
	int ix, iy;
	if(width<0)
	{	dst += width;			width= -width;		}

	if(height<0)
	{	dst += height*pitch;	height= -height;	}

	for(iy=0; iy<height; iy++)
	{
		for(ix=0; ix<width; ix++)
			dst[ix]= clr;

		dst += pitch;
	}
}

void bm16_frame(u16 *dst, int width, int height, u16 clr, int pitch)
{
	if(width<0)
	{	dst += width;			width= -width;		}

	if(height<0)
	{	dst += height*pitch;	height= -height;	}

	// Horizontal lines
	bm16_line(dst, width-1, 0, clr, pitch);
	bm16_line(&dst[(height-1)*pitch], width-1, 0, clr, pitch);

	// Vertical lines
	bm16_line(dst, 0, height-1, clr, pitch);
	bm16_line(&dst[width-1], 0, height-1, clr, pitch);
}

// EOF
