//
//! \file hello_demo.c
//!   Screen-entry text demo
//! \date 20060228 - 20060228
//! \author cearn
//
// === NOTES ===

#include <tonc.h>

int main()
{
	REG_DISPCNT= DCNT_MODE0 | DCNT_BG1;
	// base text inits
	txt_init_std();
	// tiled bg specific inits
	txt_init_se(1, BG_CBB(0)|BG_SBB(31), 0, CLR_YELLOW, 0);

	// tile map text writer
	se_puts(96, 64, "hello\n\nworld!", 0);

	while(1);

	return 0;
}
