//
// dma_demo.c
// demonstating dma timing
//
// (20031210 - 20050607, Cearn)
// === NOTES ===

#include <stdio.h>
#include <tonc.h>

#include "norf.h"

u16 g_winh[VID_HEIGHT+1];

//! Create an array of horizontal offsets for a circular window.
/*!	The offsets are to be copied to REG_WINxH each HBlank, either 
*	  by HDMA or HBlank isr. Offsets provided by modified 
*	  Bresenham's circle routine (of course); the clipping code is not
*	  optional.
*	\param winh	Pointer to array to receive the offsets.
*	\param x0	X-coord of circle origin.
*	\param y0	Y-coord of circle origin.
*	\param rr	Circle radius.
*/
void win_circle(u16 winh[], int x0, int y0, int rr)
{
	int x=0, y= rr, d= 1-rr;
	u32 tmp;

	// clear the whole array first.
	memset16(winh, 0, VID_HEIGHT+1);

	while(y >= x)
	{
		// Side octs
		tmp  = clamp(x0+y, 0, VID_WIDTH);
		tmp += clamp(x0-y, 0, VID_WIDTH)<<8;
		
		if(IN_RANGE(y0-x, 0, VID_HEIGHT))		// o4, o7
			winh[y0-x]= tmp;
		if(IN_RANGE(y0+x, 0, VID_HEIGHT))		// o0, o3
			winh[y0+x]= tmp;

		// Change in y: top/bottom octs
		if(d >= 0)		
		{
			tmp  = clamp(x0+x, 0, VID_WIDTH);
			tmp += clamp(x0-x, 0, VID_WIDTH)<<8;
			
			if(IN_RANGE(y0-y, 0, VID_HEIGHT))	// o5, o6
				winh[y0-y]= tmp;
			if(IN_RANGE(y0+y, 0, VID_HEIGHT))	// o1, o2
				winh[y0+y]= tmp;

			d -= 2*(--y);
		}
		d += 2*(x++)+3;
	}
	winh[VID_HEIGHT]= winh[0];
}

void init_main()
{
	// Init BG 2 (basic bg)
	dma3_cpy(pal_bg_mem, norfPal, norfPalLen);
	dma3_cpy(tile_mem[0], norfTiles, norfTilesLen);
	dma3_cpy(se_mem[30], norfMap, norfMapLen);
	//memcpy32(pal_bg_mem, norfPal, norfPalLen/4);
	//memcpy32(tile_mem[0], norfTiles, norfTilesLen/4);
	//memcpy32(se_mem[30], norfMap, norfMapLen/4);

	REG_BG2CNT= BG_CBB(0)|BG_SBB(30);

	// Init BG 1 (mask)
	const TILE tile= 
	{{
		0xF2F3F2F3, 0x3F2F3F2F, 0xF3F2F3F2, 0x2F3F2F3F, 
		0xF2F3F2F3, 0x3F2F3F2F, 0xF3F2F3F2, 0x2F3F2F3F
	}};
	tile_mem[0][0x0100]= tile;
	se_fill(se_mem[29], 0x1100);

	REG_BG1CNT= BG_CBB(0)|BG_SBB(29);

	// Init BG 0 (text)
	txt_init_std();
	txt_init_se(0, BG_CBB(0)|BG_SBB(28), 0xF020, CLR_ORANGE, 0);

	// Init window
	REG_WIN0H= VID_WIDTH;
	REG_WIN0V= VID_HEIGHT;

	// Enable stuff
	REG_DISPCNT= DCNT_MODE0 | DCNT_BG0 | DCNT_BG1 | DCNT_BG2 | DCNT_WIN0;
	REG_WININ= WIN_BUILD(WIN_BG0|WIN_BG2, 0);
	REG_WINOUT= WIN_BUILD(WIN_BG0|WIN_BG1, 0);
}

int main()
{
	int rr=40, x0=128, y0=120;
	char str[32];

	init_main();

	while(1)
	{
		vid_vsync();
		key_poll();

		rr += key_tri_shoulder();	// size with B/A
		x0 += key_tri_horz();		// move left/right
		y0 += key_tri_vert();		// move up/down

		if(rr<0)
			rr= 0;

		// Fill circle array
		win_circle(g_winh, x0, y0, rr);
	
		// Init win-circle HDMA
		DMA_TRANSFER(&REG_WIN0H, &g_winh[1], 1, 3, DMA_HDMA);

		SBB_CLEAR(28);
		siprintf(str, "(%d,%d) | %d", x0, y0, rr);
		se_puts(8, 8, str, 0xF020);
	}
	
	return 0;
} 

