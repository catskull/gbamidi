//======================================================================
//
//	norf, 256x256@4, 
//	+ palette 128 entries, not compressed
//	+ 24 tiles (t|f|p reduced) not compressed
//	+ regular map (in SBBs), not compressed, 32x32 
//	Total size: 256 + 768 + 2048 = 3072
//
//	Time-stamp: 2006-02-21, 01:13:26
//	Exported by Cearn's Usenti v1.7.3
//	(comments, kudos, flames to "daytshen@hotmail.com")
//
//======================================================================

#ifndef __NORF__
#define __NORF__

#define norfPalLen 256
extern const unsigned short norfPal[128];

#define norfTilesLen 768
extern const unsigned short norfTiles[384];

#define norfMapLen 2048
extern const unsigned short norfMap[1024];

#endif // __NORF__

