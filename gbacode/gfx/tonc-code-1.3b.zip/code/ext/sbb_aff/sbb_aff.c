//
// sbb_aff.c
// showing screenblock boundaries for affine backgrounds
//
// (20031115 - 20060925, Cearn)
// === NOTES ===

#include <stdio.h>
#include <tonc.h>
#include "nums.h"

#define MAP_AFF_SIZE 0x0100

// Remember, you don't have to have a buffer 
OBJ_ATTR *obj_cross= &oam_mem[0];
OBJ_ATTR *obj_disp= &oam_mem[1];

BG_AFFINE bgaff;

void init_cross()
{
	TILE cross= 
	{{  
		0x00011100, 0x00100010, 0x01022201, 0x01021201, 
		0x01022201, 0x00100010, 0x00011100, 0x00000000,
	}};
	tile_mem[4][1]= cross;

	pal_obj_mem[0x01]= pal_obj_mem[0x12]= CLR_WHITE;
	pal_obj_mem[0x02]= pal_obj_mem[0x11]= CLR_BLACK;

	obj_cross->attr2= 0x0001;
	obj_disp->attr2= 0x1001;
}

void init_map()
{
	int ii;

	memcpy32(&tile8_mem[0][1], nums8Tiles, nums8TilesLen/4);
	memcpy32(pal_bg_mem, numsPal, numsPalLen/4);

	REG_BG2CNT= BG_CBB(0) | BG_SBB(8) | BG_AFF_64x64;
	bgaff= bg_aff_dflt;

	// fill per 256 screen entries (=32x4 bands)
	u32 *pse= (u32*)se_mem[8];
	u32 ses= 0x01010101;
	for(ii=0; ii<16; ii++)
	{
		memset32(pse, ses, MAP_AFF_SIZE/4);
		pse += MAP_AFF_SIZE/4;
		ses += 0x01010101;
	}
}

void sbb_aff()
{
	AFF_SRC_EX asx= { 0, 0, 0, 0, 0x0100, 0x0100, 0 };
	const int DX=256;
	FIXED ss= 0x0100;

	char str[32];

	while(1)
	{
		vid_vsync();
		key_poll();

		// dir + A : move map in screen coords
		if(key_is_down(KEY_A))
		{
			asx.scr_x += key_tri_horz();
			asx.scr_y += key_tri_vert();
		}
		else	// dir : move map in map coords
		{
			asx.tex_x -= DX*key_tri_horz();
			asx.tex_y -= DX*key_tri_vert();
		}
		// rotate
		asx.alpha -= 128*key_tri_shoulder();

		
		// B: scale up ; B+Se : scale down
		if(key_is_down(KEY_B))
			ss += (key_is_down(KEY_SELECT) ? -1 : 1);

		// St+Se : reset
		// St : toggle wrapping flag.
		if(key_hit(KEY_START))
		{
			if(key_is_down(KEY_SELECT))
			{
				asx.tex_x= asx.tex_y= 0;
				asx.scr_x= asx.scr_y= 0;
				asx.alpha= 0;
				ss= 1<<8;
			}
			else					
				REG_BG2CNT ^= BG_WRAP;
		}

		asx.sx= asx.sy= (1<<16)/ss;

		bg_rotscale_ex(&bgaff, &asx);
		REG_BG_AFFINE[2]= bgaff;

		// the cross indicates the rotation point
		// (== p in map-space; q in screen-space)
		obj_set_pos(obj_cross, asx.scr_x-3, (asx.scr_y-3));
		obj_set_pos(obj_disp, (bgaff.dx>>8)-3, (bgaff.dy>>8)-3);

		SBB_CLEAR(31);
		siprintf(str, "p0: (%d,%d)", asx.tex_x>>8, asx.tex_y>>8);
		se_puts(8, 136, str, 0xF000);
		siprintf(str, "q0: (%d,%d)", asx.scr_x, asx.scr_y);
		se_puts(8, 144, str, 0xF000);
		siprintf(str, "dx: (%d,%d)", bgaff.dx>>8, bgaff.dy>>8);
		se_puts(8, 152, str, 0xF000);
	}	
}

int main()
{
	init_map();
	init_cross();
	txt_init_std();
	txt_init_se(0, BG_CBB(3)|BG_SBB(31),0xF000, 0x001f0000, 0xEE);

	REG_DISPCNT= DCNT_MODE1 | DCNT_BG0 | DCNT_BG2 | DCNT_OBJ;

	sbb_aff();

	return 0;
}
