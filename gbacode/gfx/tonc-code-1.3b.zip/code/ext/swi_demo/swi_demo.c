//
// swi_demo.c
//
// Demonstrates software interrupt
// Note that swi.c uses inline assembly, which is 
// compiler dependent. The THUMB/ARM thing is nicely
// circumvented by defining the swi_call macro.
//
// (20031228 - 20050607, Cearn)

#include <tonc.h>

// === swi calls ======================================================

// Their assembly equivalents can be found in tonc_bios.s

void VBlankIntrWait()
{	swi_call(0x05);	}

int Div(int num, int denom)
{	swi_call(0x06);	}

u32 Sqrt(u32 num)
{	swi_call(0x08);	}

s16 ArcTan2(s16 x, s16 y)
{	swi_call(0x0a);	}

void ObjAffineSet(const AFF_SRC *src, void *dst, int num, int offset)
{	swi_call(0x0f);	}


// === swi demos ======================================================

// NOTE!
// To be consistent with general mathematical graphs, the 
// y-axis has to be reversed and the origin moved to the 
// either the bottom or mid of the screen via
// "iy = H - y"
// or
// "iy = H/2 - y"
//
// functions have been scaled to fit the graphs on the 240x160 screen

// y= 2560/x
void div_demo()
{
	int ix, y;

	for(ix=1; ix<VID_WIDTH; ix++)
	{
		y= Div(0x0a000000, ix)>>16;
		if(y <= VID_HEIGHT)
			m3_plot(ix, VID_HEIGHT - y, CLR_RED);
	}
	m3_puts(168, 136, "div", CLR_RED);
}

// y= 160*sqrt(x/240)
void sqrt_demo()
{
	int ix, y;
	for(ix=0; ix<VID_WIDTH; ix++)
	{
		y= Sqrt(Div(320*ix, 3));
		m3_plot(ix, VID_HEIGHT - y, CLR_LIME);
	}
	m3_puts(160, 8, "sqrt", CLR_LIME);
}

// y = 80 + tan((x-120)/16) * (64)*2/pi
// ArcTan2 lies in < -0x4000, 0x4000 >
void arctan2_demo()
{
	int ix, y;
	int ww= VID_WIDTH>>1, hh= VID_HEIGHT>>1;
	for(ix=0; ix < VID_WIDTH; ix++)
	{
		y= ArcTan2(0x10, ix-ww);
		m3_plot(ix, hh - (y>>8), CLR_MAG);
	}
	m3_puts(144, 40, "atan2", CLR_MAG);


	
	// pick some random memory to show the range of arctan2
	OBJ_ATTR *obj= &oam_mem[4];
	obj->attr0= ArcTan2( 0x100,  0x100);	// q0 : 0x2000 (pi*1/4)
	obj->attr1= ArcTan2(-0x100,  0x100);	// q1 : 0x6000 (pi*3/4)
	obj->attr2= ArcTan2(-0x100, -0x100);	// q2 : 0xa000 (pi*5/4 = pi*-3/4)
	obj->fill=  ArcTan2( 0x100, -0x100);	// q3 : 0xe000 (pi*7/4 = pi*-1/4)
}

// wX= 1, wY= 80
// cc= 80*sx*cos(2*pi*alpha/240)
// ss=  1*sy*sin(2*pi*alpha/240)
void aff_demo()
{
	int ix, ss, cc;
	ObjAffineSource af_src= {0x0100, 0x5000, 0};	// sx=1, sy=80, alpha=0
	ObjAffineDest af_dest= {0x0100, 0, 0, 0x0100};	// =I (redundant)

	for(ix=0; ix<VID_WIDTH; ix++)
	{
		ObjAffineSet(&af_src, &af_dest, 1, BG_AFF_OFS);
		cc= 80*af_dest.pa>>8; 
		ss= af_dest.pc>>8;
		m3_plot(ix, 80 - cc, CLR_YELLOW);
		m3_plot(ix, 80 - ss, CLR_CYAN);
		// 0x010000/0xf0 = 0x0111.111...
		af_src.alpha += 0x0111;			// acceptable rounding error
	}
	m3_puts(48, 40, "cos", CLR_YELLOW);
	m3_puts(64, 24, "sin", CLR_CYAN);


	// sx= 2, sy= 2, 45� CCW rotation. Now all we'd need is a sprite
	af_src.sx= 0x0080; 
	af_src.sy= 0x0080; 
	af_src.alpha= 0x2000;
	ObjAffineSet(&af_src, &obj_aff_mem->pa, 1,	OBJ_AFF_OFS);
}

// === main ===========================================================

int main()
{
	REG_DISPCNT= DCNT_MODE3 | DCNT_BG2;

	txt_init_std();

	div_demo();
	sqrt_demo();
	aff_demo();

	arctan2_demo();
	
	while(1);
	
	return 0;
}
