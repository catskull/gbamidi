//
// irq_demo.c
// Interrupts: routed, nested and prioritized
//
// (20061022 - 20061024, Cearn)
// === NOTES ===


#include <stdio.h>
#include <tonc.h>

CODE_IN_IWRAM void hbl_grad_direct();

const char *strings[]= 
{
	"asm/nested", "c/direct  ", 
	"HBlank", "VCount"
};

// Function pointers to master isrs
const fnptr master_isrs[2]= 
{
	(fnptr)isr_master_nest,
	(fnptr)hbl_grad_direct 
};


// (1) Uses tonc_isr_nest.s  isr_master_multi() as a switchboard
void hbl_grad_routed()
{
	u32 clr= REG_VCOUNT/8;
	pal_bg_mem[0]= RGB15(clr, 0, 31-clr);
}

// (2) VCT is triggered at line 80; this waits 40 scanlines
void vct_wait()
{
	pal_bg_mem[0]= CLR_RED;
	while(REG_VCOUNT<120);
}

int main()
{
	u32 bDirect=0, bVctPrio= 0;
	char str[32];

	txt_init_std();
	txt_init_se(0, BG_CBB(0)|BG_SBB(31), 0, CLR_ORANGE, 0);
	se_puts(8, 8, "ISR : \nPrio: \nIE  : ", 0);
	se_puts(56,  8, strings[bDirect], 0);
	se_puts(56, 16, strings[2+bVctPrio], 0);

	REG_DISPCNT= DCNT_MODE0 | DCNT_BG0;

	// (3) Initialise irqs; add HBL and VCT isrs 
	// and set VCT to trigger at 80
	irq_init(master_isrs[0]);
	irq_add(II_HBLANK, hbl_grad_routed);
	BF_SET(REG_DISPSTAT, 80, DSTAT_VCT);
	irq_add(II_VCOUNT, vct_wait);

	while(1)
	{
		vid_vsync();
		key_poll();

		// Toggle HBlank irq
		if(key_hit(KEY_R))
			REG_IE ^= IRQ_HBLANK;

		// Toggle Vcount irq
		if(key_hit(KEY_L))
			REG_IE ^= IRQ_VCOUNT;

		siprintf(str, "%04X", REG_IE);
		se_puts(56, 24, str, 0);

		// (4) Toggle between 
		// asm switchblock + hbl_gradient (red, descending)
		// or purely hbl_isr_in_c (green, ascending)
		if(key_hit(KEY_A))
		{
			bDirect ^= 1;
			irq_set_master(master_isrs[bDirect]);
			se_puts(56,  8, strings[bDirect], 0);
		}

		// (5) Switch priorities of HBlank and VCount
		if(key_hit(KEY_B))
		{
			irq_set(II_VCOUNT, vct_wait, bVctPrio);
			bVctPrio ^= 1;
			se_puts(56, 16, strings[2+bVctPrio], 0);
		}
	}

	return 0;
}
