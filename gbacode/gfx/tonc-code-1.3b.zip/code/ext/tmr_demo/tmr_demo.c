// 
// tmr_demo.c
// demonstrating a cascade timer
//
// (20031220 -20060302, Cearn)
 
#include <stdio.h>
#include <tonc.h>

void tmr_test()
{
	// Overflow every ~1 second:
	// 0x4000 ticks @ FREQ_1024

	REG_TM2D= -0x4000;	// 0x4000 ticks till overflow
	REG_TM2CNT= TM_FREQ_1024;	// we're using the 1024 cycle timer	

	// cascade into tm3
	REG_TM3CNT= TM_ON | TM_CASCADE;

	u32 sec= -1;
	char str[32];

	while(1)
	{
		vid_vsync();
		key_poll();

		if(REG_TM3D != sec)
		{
			// NOTE: div and mod are slow; there are better ways, 
			// but that's not really of interest right now

			sec= REG_TM3D;
			siprintf(str, "%02d:%02d:%02d", 
				sec/3600, (sec%3600)/60, sec%60);
			se_puts(88, 80, str, 0);
			
		}

		if(key_hit(KEY_START))	// pause by disabling timer
			REG_TM2CNT ^= TM_ON;
		if(key_hit(KEY_SELECT))	// pause by enabling cascade
			REG_TM2CNT ^= TM_CASCADE;
	}
}

int main()
{
	txt_init_std();
	txt_init_se(0, BG_CBB(0)|BG_SBB(2), 0, CLR_ORANGE, 0);

	REG_DISPCNT= DCNT_MODE0 | DCNT_BG0;

	tmr_test();

	return 0;
}
