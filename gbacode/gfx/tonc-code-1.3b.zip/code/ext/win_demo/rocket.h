//======================================================================
//
//	rocket, 16x16@4, 
//	+ palette 16 entries, not compressed
//	+ 4 tiles not compressed
//	Total size: 32 + 128 = 160
//
//	Time-stamp: 2006-01-04, 18:14:01
//	Exported by Cearn's Usenti v1.7.1
//	(comments, kudos, flames to "daytshen@hotmail.com")
//
//======================================================================

#ifndef __ROCKET__
#define __ROCKET__

#define rocketPalLen 32
extern const unsigned int rocketPal[8];

#define rocketTilesLen 128
extern const unsigned int rocketTiles[32];

#endif // __ROCKET__

