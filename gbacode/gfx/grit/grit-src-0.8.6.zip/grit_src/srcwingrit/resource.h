//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by wingrit.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_WINGRITTYPE                  129
#define IDR_TEXTBAR                     131
#define IDD_XP_GBA                      133
#define IDD_XPLOG                       134
#define IDD_PAL_VIEW                    135
#define IDC_LEFT                        1011
#define IDC_TOP                         1012
#define IDC_WIDTH                       1013
#define IDC_HEIGHT                      1014
#define IDC_START                       1017
#define IDC_COUNT                       1018
#define IDC_FILE_PATH                   1058
#define IDC_FILE_BROWSE                 1059
#define IDC_PAL_MODE                    2060
#define IDC_PAL_ID                      2061
#define IDC_PAL_VAL                     2062
#define IDC_PAL_VIEW                    2064
#define IDS_FLTR_GBA                    2103
#define IDC_PAL_CHK                     3010
#define IDC_PAL_TRANS                   3011
#define IDC_IMG_CHK                     3020
#define IDC_IMG_MODE                    3021
#define IDC_IMG_BPP                     3023
#define IDC_IMG_CPRS                    3024
#define IDC_IMG_TRANS                   3025
#define IDC_OBJ_CUSTOM                  3030
#define IDC_OBJ_SQR                     3031
#define IDC_OBJ_WIDE                    3032
#define IDC_OBJ_TALL                    3033
#define IDC_OBJ_8                       3034
#define IDC_OBJ_16                      3035
#define IDC_OBJ_32                      3036
#define IDC_OBJ_64                      3037
#define IDC_OBJ_HORZ                    3038
#define IDC_OBJ_VERT                    3039
#define IDC_MAP_CHK                     3050
#define IDC_MAP_FLAT                    3051
#define IDC_MAP_SBB                     3052
#define IDC_MAP_AFF                     3053
#define IDC_MAP_RDX                     3054
#define IDC_MAP_RDX_PAL                 3055
#define IDC_MAP_RDX_FLIP                3056
#define IDC_META_PAL                    3057
#define IDC_MAP_CPRS                    3058
#define IDC_MAP_OFS                     3059
#define IDC_AREA_CSM                    3061
#define IDC_AREA_IMG                    3062
#define IDC_AREA_SEL                    3063
#define IDC_FILE_TYPE                   3071
#define IDC_FILE_HDR                    3072
#define IDC_FILE_CAT                    3073
#define IDC_RIFF_CHK                    3074
#define IDC_VAR_CHK                     3075
#define IDC_VAR_NAME                    3076
#define IDC_VAR_8                       3077
#define IDC_VAR_16                      3078
#define IDC_VAR_32                      3079
#define IDC_TILESET_CHK                 3080
#define IDC_TILESET_PATH                3081
#define IDC_TILESET_BROWSE              3082
#define IDC_SUMMARY                     3090
#define IDM_DOC_UPDATE                  32678
#define ID_VIEW_GBAEXPORT               32780
#define ID_EDIT_QUANT_WU                32781
#define ID_EDIT_QUANT_NN                32782
#define ID_EDIT_CONVERTTO555            32783
#define ID_VIEW_PAL                     32784
#define ID_STDERR_TEST                  32785

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32786
#define _APS_NEXT_CONTROL_VALUE         1077
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
